@echo off
python -m pyfishstrap %*
pause
