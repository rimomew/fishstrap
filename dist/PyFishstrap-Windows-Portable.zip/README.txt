PyFishstrap - Python Roblox Bootstrapper
=========================================

This is a portable version of PyFishstrap for Windows.

REQUIREMENTS:
- Python 3.10 or higher must be installed
- pip must be available

HOW TO USE:
1. Extract this ZIP file to any folder
2. Open Command Prompt in the extracted folder
3. Install dependencies: pip install -r requirements.txt
4. Run the application: python -m pyfishstrap

QUICK LAUNCH:
- Double-click run.bat to launch the main menu
- Double-click run_player.bat to launch Roblox Player
- Double-click run_studio.bat to launch Roblox Studio

COMMAND LINE OPTIONS:
--player      Launch Roblox Player
--studio      Launch Roblox Studio
--quiet       Run in quiet mode (no UI)
--menu        Open settings menu
--uninstall   Uninstall the application
--settings    Open settings
--watcher     Open watcher
--bloxshade   Open Bloxshade configuration

PROJECT: https://github.com/rimomew/fishstrap
PyFishstrap: A Python reimplementation
