@echo off
python -m pyfishstrap --player %*
pause
