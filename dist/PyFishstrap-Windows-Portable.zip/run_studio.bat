@echo off
python -m pyfishstrap --studio %*
pause
